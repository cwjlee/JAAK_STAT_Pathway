##### Experimental Aim 2A #####
##### Load Packages #####
library(phyloseq)
library(ape)
library(tidyverse)
library(vegan)

##### Load data #####
metadysdat  <- "new_metadata.tsv"
meta <- read.delim(file = metadysdat, sep = "\t")

otudat <- "feature-table.txt"
otu <- read_delim(file = otudat, delim = "\t", skip = 1)

taxdat <- "taxonomy.tsv"
tax <- read_delim(file = taxdat, delim = "\t")

phylotreedat <- "tree.nwk"
phylotree <- read.tree(phylotreedat)

#### Format OTU table ####
otu_mat <- as.matrix(otu[,-1])
rownames(otu_mat) <- otu$`#OTU ID`
OTU <- otu_table(otu_mat, taxa_are_rows = TRUE)

#### Format sample metadata ####
meta_df <- as.data.frame(meta[,-1])
rownames(meta_df) <- meta$sample.id
meta_adj_df <- mutate(meta_df, Num.Age.New.Bin = case_when(Age.New.Bin == 'young' ~ '1',
                                                           Age.New.Bin == 'middle' ~ '2',
                                                           Age.New.Bin == 'old' ~  '3'))
meta_adj_df$Num.Age.New.Bin <- as.numeric(as.character(meta_adj_df$Num.Age.New.Bin))
META <- sample_data(meta_adj_df)

#### Format taxonomy ####
tax_mat <- tax %>% select(-Confidence) %>%
  separate(col = Taxon, sep = "; "
           , into = c("Domain","Phylum","Class","Order","Family","Genus","Species")) %>%
  as.matrix()
tax_mat <- tax_mat[,-1]
rownames(tax_mat) <- tax$`Feature ID`
TAX <- tax_table(tax_mat)

#### Create phyloseq object ####
dysautonomia <- phyloseq(OTU, META, TAX, phylotree)

#### Filter ####
# Remove non-bacterial, mitochondria, and chloroplast sequences
dysautonomia_filt <- subset_taxa(dysautonomia,  Domain == "d__Bacteria" & Class!="c__Chloroplast" & Family !="f__Mitochondria")
# Remove ASVs that have less than 5 counts total
dysautonomia_filt_nolow <- filter_taxa(dysautonomia_filt, function(x) sum(x) > 5, prune = TRUE)
# Remove samples with less than 100 reads
dysautonomia_filt_nolow_samps <- prune_samples(sample_sums(dysautonomia_filt_nolow) > 100, dysautonomia_filt_nolow)
# Remove samples where FD severity is NA
dysautonomia_final <- subset_samples(dysautonomia_filt_nolow_samps, !is.na(Test.FD.severity))

# Rarefy samples
rarecurve(t(as.data.frame(otu_table(dysautonomia_final))), cex = 0.1)
dysautonomia_rare <- rarefy_even_depth(dysautonomia_final, rngseed = 1, sample.size = 9000)

#Distribution of FD severity across ages
META_FD_Age <- select(meta_adj_df, Test.FD.severity, Age.New.Bin)
META_FD_Age <- filter(META_FD_Age, !is.na(Test.FD.severity))
graph_without_count <- ggplot(META_FD_Age, aes(x = Test.FD.severity, y = Age.New.Bin)) + geom_count()
graph_with_count <- graph_without_count + geom_text(data = ggplot_build(graph_without_count)$data[[1]],aes(x, y, label = n, vjust= -2))

#### Alpha Diversity ####
plot_richness(dysautonomia_rare)
plot_richness(dysautonomia_rare, measures = c("Shannon","Observed"))
plot_richness(dysautonomia_rare, x = "Test.FD.severity", measures = c("Shannon","Observed")) +
  xlab("FD Severity") +
  geom_boxplot()

#### Beta Diversity ####
#Bray Curtis
bc_dm <- distance(dysautonomia_rare, method = "bray")
pcoa_bc <- ordinate(dysautonomia_rare, method = "PCoA", distance = bc_dm)
plot_ordination(dysautonomia_rare, pcoa_bc, color = "Test.FD.severity") +
  labs(pch="FD Severity")

#Jaccard
jac_dm <- distance(dysautonomia_rare, method = "jaccard", binary = TRUE)
pcoa_jac <- ordinate(dysautonomia_rare, method = "PCoA", distance = jac_dm)
plot_ordination(dysautonomia_rare, pcoa_jac, color = "Test.FD.severity") +
  labs(pch="FD Severity")

#Unweighted Unifrac
uuf_dm <- distance(dysautonomia_rare, method = "uunifrac")
pcoa_uuf <- ordinate(dysautonomia_rare, method = "PCoA", distance = uuf_dm)
plot_ordination(dysautonomia_rare, pcoa_uuf, color = "Test.FD.severity") +
  labs(pch="FD Severity")

#Weighted Unifrac
wuf_dm <- distance(dysautonomia_rare, method = "wunifrac")
pcoa_wuf <- ordinate(dysautonomia_rare, method = "PCoA", distance = wuf_dm)
plot_ordination(dysautonomia_rare, pcoa_wuf, color = "Test.FD.severity") +
  labs(pch="FD Severity")

#### Beta Diversity for Age ####
#Bray Curtis
bc_dm <- distance(dysautonomia_rare, method = "bray")
pcoa_bc <- ordinate(dysautonomia_rare, method = "PCoA", distance = bc_dm)
gg_pcoa_bray <- plot_ordination(dysautonomia_rare, pcoa_bc, color = "Num.Age.New.Bin", shape = "FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_bray.png"
       , gg_pcoa_bray
       , height = 4, width = 5)

gg_pcoa_bray_ms <- plot_ordination(dysautonomia_rare, pcoa_bc, color = "Num.Age.New.Bin", shape = "Test.FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_bray_mild_severe_only.png"
       , gg_pcoa_bray_ms
       , height = 4, width = 5)

#Jaccard
jac_dm <- distance(dysautonomia_rare, method = "jaccard", binary = TRUE)
pcoa_jac <- ordinate(dysautonomia_rare, method = "PCoA", distance = jac_dm)
gg_pcoa_jac <- plot_ordination(dysautonomia_rare, pcoa_jac, color = "Num.Age.New.Bin", shape = "FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_jac.png"
       , gg_pcoa_jac
       , height = 4, width = 5)

gg_pcoa_jac_ms <- plot_ordination(dysautonomia_rare, pcoa_jac, color = "Num.Age.New.Bin", shape = "Test.FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_jac_mild_severe_only.png"
       , gg_pcoa_jac_ms
       , height = 4, width = 5)

#Unweighted Unifrac
uuf_dm <- distance(dysautonomia_rare, method = "uunifrac")
pcoa_uuf <- ordinate(dysautonomia_rare, method = "PCoA", distance = uuf_dm)
gg_pcoa_unweighted <- plot_ordination(dysautonomia_rare, pcoa_uuf, color = "Num.Age.New.Bin", shape = "FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_unweighted_unifrac.png"
       , gg_pcoa_unweighted
       , height = 4, width = 5)

gg_pcoa_unweighted_ms <- plot_ordination(dysautonomia_rare, pcoa_uuf, color = "Num.Age.New.Bin", shape = "Test.FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_unweighted_unifrac_mild_severe_only.png"
       , gg_pcoa_unweighted_ms
       , height = 4, width = 5)

#Weighted Unifrac
wuf_dm <- distance(dysautonomia_rare, method = "wunifrac")
pcoa_wuf <- ordinate(dysautonomia_rare, method = "PCoA", distance = wuf_dm)
gg_pcoa_weighted <- plot_ordination(dysautonomia_rare, pcoa_wuf, color = "Num.Age.New.Bin", shape = "FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_weighted_unifrac.png"
       , gg_pcoa_weighted
       , height = 4, width = 5)

gg_pcoa_weighted_ms <- plot_ordination(dysautonomia_rare, pcoa_wuf, color = "Num.Age.New.Bin", shape = "Test.FD.severity") +
  scale_color_gradient(low = "orange", high = "darkblue") +
  labs(pch="FD Severity", col = "Age")

ggsave(filename = "plot_pcoa_weighted_unifrac_mild_severe_only.png"
       , gg_pcoa_weighted_ms
       , height = 4, width = 5)

#### PERMANOVA Statistics ####
dys_dat_wdiv <- data.frame(sample_data(dysautonomia_rare), estimate_richness(dysautonomia_rare))
#Bray Curtis
dm_bray <- vegdist(t(otu_table(dysautonomia_rare)), method = "bray")
adonis2(dm_bray ~ Test.FD.severity*Age.New.Bin, data = dys_dat_wdiv)
#Jaccard
dm_jaccard <- vegdist(t(otu_table(dysautonomia_rare)), method = "jaccard")
adonis2(dm_jaccard ~ Test.FD.severity*Age.New.Bin, data = dys_dat_wdiv)
#Unweighted Unifrac
dm_uunifrac <- UniFrac(dysautonomia_rare, weighted = FALSE)
adonis2(dm_uunifrac ~ Test.FD.severity*Age.New.Bin, data = dys_dat_wdiv)
#Weighted Unifrac
dm_wunifrac <- UniFrac(dysautonomia_rare, weighted = TRUE)
adonis2(dm_wunifrac ~ Test.FD.severity*Age.New.Bin, data = dys_dat_wdiv)
